#include "dlist.h"
#include <malloc.h>
/*
* File:   dlist.c：通用双向链表函数实现
* Author: ecorefeng
* Created on 2010年8月13日
*/

/*
*功能：实现一个DList结构体的初始化
*参数：void
*返回：DList结构体
*/
//..........create head..............
DList *dlist_create()
{
    DList  *dlist = (DList *)calloc(1, sizeof(DList));
    if(dlist == NULL)
    {
        return NULL;
    }

    dlist->head  = (DListNode *)calloc(1, sizeof(DListNode));
    if(dlist->head == NULL)
    {   
        free(dlist);
        dlist = NULL;

        return NULL;
    }
    dlist->current = dlist->head;

    return dlist;
}
/*
*分配内存
*/
//........malloc  node..................
static DListNode *dlist_alloc()
{
    return (DListNode *)calloc(1, sizeof(DListNode));
}
/*
*检查输入的数据
*/
//............ data check.........
int data_dlist_check(DList *dlist,  void *data)
{   
    int flag = 1;
    // No head
    if(dlist == NULL)
    {
           return flag = 0;
    }
    // Incorrect data
       if(data == NULL)
    {
        return flag = 0;
    }

    return flag;
}

/*
*功能：添加元素
*参数：dlist:指定链表  index: 添加的位置 data：加入的数据的指针
*返回：Ret
*/
Ret dlist_add(DList *dlist, int index,  void *data)
{
    int flag = 1;
    int len = 0;
    DListNode *node = NULL;
    DListNode *dlistnode = NULL;
    return_val_if_fail(dlist != NULL&&data != NULL, RET_FAULT);
   
    flag = data_dlist_check(dlist, data);
    if(flag == 0)
    {
        return RET_FAULT;
    }
   
    len = dlist_len(dlist);
    return_val_if_fail(index <= len, RET_FAULT);

    if(index > len )
    {
        return RET_FAULT;
    }   

    node =    dlist_alloc();
    if(node == NULL)
    {
        return RET_OOM;
    }

    node->data =data;
//    node->data = strcpy(data);
    if( (len == 0 &&index == 0)|| index < 0)
    {   
        //tail
        dlist->current->next = node;
        node->prev = dlist->current;
        dlist->current = node;

        return RET_OK;
    }
    else if(len != 0&& index == 0)
    {   
        //head
        dlist->head->next->prev = node;
        node->prev = dlist->head;
        node->next = dlist->head->next;
        dlist->head->next = node;
       
        return RET_OK;
    }
    else if(len != 0&& index !=0)
    {
        dlistnode =    dlist_get(dlist, index);

        if(dlistnode == NULL)
        {
            return RET_FAULT;
        }
        dlistnode->prev->next = node;
        node->prev = dlistnode->prev;
        node->next = dlistnode;
        dlistnode->prev = node;
       
        return RET_OK;
    }

    return RET_FAULT;
}
/*
*功能：删除指定位置的值
*参数：参数：dlist:指定链表 index：位置
*/
//.........del.............
Ret dlist_delete(DList *dlist, int index)
{
    int len = 0;
    DListNode *dlistnode = NULL;
    return_val_if_fail(dlist != NULL, RET_FAULT);

    if(dlist == NULL)
    {
        return RET_FAULT;
    }

    len = dlist_len(dlist);
    //
    return_val_if_fail(index <= len, RET_FAULT);

    if(index > len )
    {
        return RET_FAULT;
    }
   
    if(index > 0&&index <len)
    {
        dlistnode =    dlist_get(dlist, index);
        if(dlistnode == NULL)
        {
            return RET_FAULT;
        }

        dlistnode->next->prev = dlistnode->prev;
        dlistnode->prev->next = dlistnode->next;
        dlistnode->prev = NULL;
        dlistnode->next = NULL;
        dlistnode->data = NULL;
        free(dlistnode);

        dlistnode = NULL;

        return RET_OK;
    }
    else if(index <= 0 || index == len)
    {
        dlistnode = dlist->current->prev;
        dlist->current->prev->next = NULL;
        dlist->current->prev = NULL;
        dlist->current->data = NULL;
        free(dlist->current);
        dlist->current = dlistnode;

        return RET_OK;
    }

    return  RET_FAULT;
}
/*
*功能：得到节点
*参数：dlist:要操作的链表指针地址 index:位置
*/
//..........get node.......
DListNode *dlist_get(DList *dlist, int index)
{
    return_val_if_fail(dlist != NULL, NULL);

    int n = 1;
    DListNode *dlistnode = NULL;

    dlistnode = dlist->head;
    while (n <= index)
    {
        dlistnode = dlistnode->next;
        n = n + 1;
    }
   
    return dlistnode;
}

/*
*功能：遍历
*参数：dlist:指定链表 visitfunc：回调函数 ctx：上下文
*返回：Ret
*/
void *dlist_foreach(DList *dlist, VisitFunc visit_func,void *ctx)
{
    return_val_if_fail(dlist != NULL&&visit_func !=NULL, NULL);
   
    DListNode *ipointer = NULL;
    void  *retp = NULL;

    ipointer = dlist->head->next;
    for (ipointer ; ipointer != NULL; )
    {
        retp = visit_func(ctx, ipointer->data);
        ipointer = ipointer->next;
    }

    return retp;
}
/*
*功能：长度
*参数：dlist:指定链表
*返回：大小
*/
int dlist_len(DList *dlist)
{
    return_val_if_fail(dlist != NULL, RET_FAULT);
   
    int len = 0;
    DListNode *dlistnode = NULL;

    dlistnode = dlist->head;
    while (dlistnode->next != NULL)
    {
        dlistnode = dlistnode->next;
        len = len + 1;
    }
   
    return len;
}
/*
*功能：释放指定链表内存
*参数：dlist:指定链表
*返回：Ret
*/
//..........free list .............
Ret dlist_destroy(DList *dlist, DesFunc des_func, int index)
{
    DListNode* cursor = NULL;

    if(des_func != NULL)
    {
        des_func(dlist, index);
    }
    else
    {
        while (dlist->current != NULL && dlist->current != dlist->head)
        {
            cursor = dlist->current->prev;
            free(dlist->current);
                dlist->current = cursor ;
        }
        if(dlist->head != NULL)
        {
            free(dlist->head);
               dlist->head = NULL;
            dlist->current = NULL;
        }
        if(dlist != NULL)
        {
            free(dlist);
            dlist = NULL;
        }   
    }

    return RET_OK;
}
