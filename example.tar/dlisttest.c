#include "dlist.h"
#include <stdio.h>
#include <assert.h>
#include <string.h>
#include <ctype.h>
#include <malloc.h>
/*
* File:   dlisttest.c：关于通用链表的测试
* Author: ecorefeng
* Created on 2010年8月
*/


void test_dlist_int();
void test_dlist_string();
void *str_toupper(void *ctx, void *data);
void delete(DList *dlist, int index);
void *print_string(void *ctx, void *data);
void *max(void *ctx, void *data);
void *sum_cb(void *ctx, void *data);
void *print_int(void *ctx, void *data);
void *destroy_data_p(void *ctx, void *data);

int main (int argc, char* argv[])
{
    test_dlist_int();
   
    test_dlist_string();   
}

void test_dlist_string()
{

    char  *a = "AAaa777777abb";
    char  *b = "bbb444444bbbb";
    char  *c = "cccc3rrrrr5555555555ccccccc";
    char  *e = "eeee88888888888eeeee";
    int i = 0;
    DListNode *dlnode = NULL;
    DList *dlist = NULL;
   
    dlist = dlist_create();

    assert( 0 == dlist_len(dlist));

    for(i=0; i<10; i++)
    {
        dlist_add(dlist, -1,strdup(a));
    }

    assert( 10 == dlist_len(dlist));
    dlist_add(dlist, 6,strdup(c));
    dlist_add(dlist, -1,strdup(c));
    dlist_add(dlist, -1,strdup(c));

    dlist_destroy(dlist, delete, 13);
    dlist_destroy(dlist, delete, 5);
    dlist_destroy(dlist, delete, -1);
    dlist_destroy(dlist, delete, -1);

    dlist_add(dlist, 0,strdup(b));
    dlist_add(dlist, 1,strdup(e));   

    assert( 11 == dlist_len(dlist));

    printf("..............链中字母..................../n");

    dlist_foreach(dlist, print_string, NULL);

    dlist_foreach(dlist, str_toupper, NULL);

    printf("..............转换后字母..................../n");
   
    dlist_foreach(dlist, print_string, NULL);

    dlist_foreach(dlist, destroy_data_p, NULL);
    dlist_destroy(dlist,NULL,0);

}

void *print_string(void *ctx, void *data)
{
    printf("%s/n",(char *)data);

    return NULL;
}

void delete(DList *dlist, int index)
{
    int len = dlist_len(dlist);
    if(index < 0 || index == len)
    {
        free(dlist->current->data);
    }
    else
    {
        free(dlist_get(dlist,index)->data);
    }
    dlist_delete(dlist,index);
}

void *str_toupper(void *ctx, void *data)
{
    //    char temp_str[256]={0};
    //    strcpy(temp_str,data);
    char *temp = data;

    if(temp != NULL)
    {
        while(*temp != '/0')
        {
            if(isalpha(*temp))
            {
                if(islower(*temp))
                {
                    *temp = toupper(*temp);
                }
            }
            temp++;   
        }
    }   
}

void *destroy_data_p(void *ctx, void *data)
{
    free(data);
    return NULL;
}

void test_dlist_int()
{
    int p = 0 ;   
    int a = 111;
    int b = 222;
    int c = 333;
    int e = 444;
    int f = 555;
    int h = 1000;
    int j = 6663;
    int k = 777;
    DListNode *dlnode = NULL;
    DList *dlist = NULL;
   
    dlist = dlist_create();

    for(p=0; p<10; p++)
    {
        dlist_add(dlist, 0,&a);
    }

    assert( 10 == dlist_len(dlist));
    dlist_add(dlist, 4, &j);

    dlist_add(dlist, 3, &h);
    dlist_add(dlist, -1, &j);
   
    dlist_add(dlist, -1, &j);
    dlist_delete(dlist, 14);
    dlist_delete(dlist, 8);

    dlist_delete(dlist,-1);
    assert( 11 == dlist_len(dlist));

    printf("........数字..................../n");

    dlist_foreach(dlist, print_int, NULL);

    long sum = 0;
    void *temp = dlist_foreach(dlist, sum_cb, &sum);
    printf("======求和=====%d/n",*(long *)temp);

    long sum1 = 0;
    void *temp1 = dlist_foreach(dlist, max, &sum1);
    printf("=====最大值======%d/n",*(long *)temp1);

    dlist_destroy(dlist,NULL,0);

}

void *max(void *ctx, void *data)
{
    long *result = ctx;
    if(*(int *)data >= *result)
    {
        *result = *(int *)data;
    }
   
    return result;
}

void *sum_cb(void *ctx, void *data)
{
    long *result = ctx;
    *result += *(int *)data;
       
    return result;
}

void *print_int(void *ctx, void *data)
{
    printf("%d/n",*(int*)data);

    return NULL;
}
